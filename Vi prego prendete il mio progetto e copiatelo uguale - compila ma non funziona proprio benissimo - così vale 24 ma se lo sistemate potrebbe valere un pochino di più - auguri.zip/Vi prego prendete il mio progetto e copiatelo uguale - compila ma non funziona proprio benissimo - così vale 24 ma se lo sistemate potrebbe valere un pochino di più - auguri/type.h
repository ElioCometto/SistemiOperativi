#include <errno.h>
#include <fcntl.h>
#include <semaphore.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/* File di LOGGING */
#define LOGPATH "./logfile.txt"

/* Chiavi risorse */
#define SEM_KEY 1994
#define AB_MSGQ_KEY 1966
#define AG_MSGQ_KEY 1945
#define BA_MSGQ_KEY 1934
#define SHM_KEY 1830
#define START_SEM_KEY 2018

/*Per semctl quando è necessario arg*/
#if (defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)) || defined(__FreeBSD__) || (defined(__APPLE__) && defined(__MACH__))
/* union semun is defined by including <sys/sem.h> */
#else
union semun {
	int val;
	struct semid_ds* buf;
	unsigned short* array;
#if defined(_linux_)
	struct seminfo* _buf;
#endif
};
#endif


/* Tipo di dato per rappresentare un processo come persona */
typedef struct person_s {
	int is_b;
	char *name;
	unsigned long gen;
	int pid;
} Person;

/*Struttura dei messaggi per inviare dati di processi*/
struct infomsg {
	long mtype; /*Tipo di messaggio*/
	Person p;   /*informazioni di una persona*/
};

/* Struttura dei messaggi per inviare accettazione accopiamento */
struct lovemsg {
	long mtype;         /*Tipo di messaggio*/
	int accepted;       /* determina il rifiuto/accetazione della proposta*/
};

/* nodo lista di persone */
typedef struct node_s {
	Person p;
	struct node_s *next;
} Node;

typedef struct inode_s {
	int num;
	struct inode_s *next;
} iNode;

/* ------ Firme metodi ------ */
void errExit(char *s);
int initSem(int semId, int semNum, int val);
int reserveSem(int semId, int semNum);
int releaseSem(int semId, int semNum);
Person reproduce(Person parent1, Person parent2, unsigned long genes, int *tota, int *totb);
unsigned long mcd(unsigned long a, unsigned long b);
void spawn_process(Person child, int totB, iNode **pids);
void update_highscores(Person p, unsigned long *maxgen, int *maxname, Person *pmaxg, Person *pmaxn, int *minPID);
void start_timer(int seconds, int signal);
void print_person(Person p);
char * itoa(int i);
void add_to_list(Node **h, Person p);
void delete_from_list(Node **h, int pid);
int findn(int num);
void add_int_to_list(iNode **h, int num);
void delete_int_from_list(iNode **h, int num);
int find_min(iNode *h);
