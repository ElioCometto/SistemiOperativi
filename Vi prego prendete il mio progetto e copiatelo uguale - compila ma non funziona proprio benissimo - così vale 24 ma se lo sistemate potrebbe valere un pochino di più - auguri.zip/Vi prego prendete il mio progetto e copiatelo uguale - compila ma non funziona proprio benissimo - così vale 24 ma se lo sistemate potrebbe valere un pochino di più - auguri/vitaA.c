/*
	TODO aggiungere stampe di cosa sta facendo il programma
	del tpo "[PROGRAMMA]messaggio" oppure "[PROGRAMMA]{id_processo}messaggio"
	Esempio nel metodo handler e vitaB.c
	*/

/*
	TODO probabilmente potrebbe succedere che un processo A accetti un B ma un altro B sia riuscito a recuperare le info di A e contattarlo.
	In questo caso il secondo B resterà in attesa di ricevere risposta senza però mai riceverla.
	Dovrebbe essere raro, ma potrebbe... In tal caso bisogna inventarsi qualcosa per sistemare, probabilmente un timer o altro
	*/
#include "type.h"

/* Gestione segnali */
volatile int stop_simulation = 0;

/* Handler dei segnali */
/* (per ragioni di sicurezza le stampe da handler non sono raccomandabili) */
static void handler(int sig) {
	if (sig == SIGTERM) {
		printf("[VITA_A] Ricevuto SIGTERM dal gestore.!\n");
		stop_simulation  = 1;
		return;
	}
}

/*-------------------------------------------------*/
/* --------- METODO PRINCIPALE DI VITA A --------- */
/*-------------------------------------------------*/
int main(int argc, char const *argv[]) {
	/* Risorse */
	int shm_id, sem_id, ba_msgq_id, ab_msgq_id, ag_msgq_id, startsem;
	/* Messaggi */
	struct infomsg msgp;
	struct lovemsg msgp2;
	int countMsgBA = 0;
	/* Flags */
	int adapted = 0, accepted = 0;
	/* Persone (processi) */
	Node *persons = NULL;
	Person self, pretendente;
	int totB = 0;

	printf("[VITA_A]{%d} Sono stato creato!\n", getpid());
	/* Associazione segnali con handler */
	if (signal(SIGUSR1, handler) == SIG_ERR) errExit("[ERRORE]signal A");

	/* Recupera info da argv e crea persona */
	self.is_b = atoi(argv[1]);
	self.name = (char *)argv[2];
	self.gen = (unsigned long) atoi(argv[3]);
	self.pid = getpid();
	totB = atoi(argv[4]);


	/* --------- Associazione risorse ---------*/

	/* Ottieni code di messaggi */
	ba_msgq_id = msgget(BA_MSGQ_KEY, 0666);
	if (ba_msgq_id == -1) errExit("[ERRORE]msgget BA");
	ab_msgq_id = msgget(AB_MSGQ_KEY, 0666);
	if (ab_msgq_id == -1) errExit("[ERRORE]msgget AB");
	ag_msgq_id = msgget(AG_MSGQ_KEY, 0666);
	if (ag_msgq_id == -1) errExit("[ERRORE]msgget AG");

	/* Semaforo memoria condivisa */
	sem_id = semget(SEM_KEY, 1, 0666);
	if (sem_id == -1) errExit("[ERRORE]semget 1");

	/* Semaforo inizio */
	startsem = semget(START_SEM_KEY, 1, IPC_CREAT | 0666);
	if (startsem == -1) errExit("[ERRORE]semget 1");

	/* Attaccati alla memoria */
	shm_id = shmget(SHM_KEY, sizeof(Person), 0666);
	if (shm_id == -1) errExit("[ERRORE]shmid");
	persons = (Node *)shmat(shm_id, NULL, 0);
	if (persons == (void *) -1) errExit("[ERRORE]shmat");

	/* --------- Associazione risorse ---------*/
	printf("[VITA_A]{%d} Ho recuperato le risorse.\n", getpid());


	if (reserveSem(startsem, 0) == -1) errExit("[ERRORE]reserveSem");
	while (!accepted && !stop_simulation) {
		printf("[VITA_A]{%d} Provo a pubblicare le mie informazioni.\n", getpid());
		/* Scrivi in memoria condivisa */
		if (reserveSem(sem_id, 0) == -1) errExit("[ERRORE]reserveSem");
		add_to_list(&persons, self);
		if (releaseSem(sem_id, 0) == -1) errExit("[ERRORE]releaseSem");

		printf("[VITA_A]{%d} Ho pubblicato le mie informazioni, resto in attesa di un pretendente.\n", getpid());

		/* Attendi di essere contattato da un B (legge solo messaggi di tipo == getpid()) */
		if (msgrcv(ba_msgq_id, &msgp, sizeof(Person), getpid(), 0666) == -1) errExit("[ERRORE]msgrcv");
		pretendente = msgp.p;
		countMsgBA++;

		/* Cancello le mie info da memoria condivisa per evitare deadlock */
		if (reserveSem(sem_id, 0) == -1) errExit("[ERRORE]reserveSem");
		delete_from_list(&persons, self.pid);
		if (releaseSem(sem_id, 0) == -1) errExit("[ERRORE]releaseSem");

		/* Decidi se accoppiarti */
		printf("[VITA_A]{%d}Sto per decidere se voglio accoppiarmi con %d.\n", getpid(), pretendente.pid);
		if (pretendente.gen % self.gen) {
			/* Accetta sempre multipli */
			accepted = 1;
		} else if (adapted) {
			/* Per regole i genomi dei genitori posso avere genoma min pari a 2 */
			/* non accetta solo i casi peggiori in cui MDC è 1 ->gen figli basso */
			if (mcd(pretendente.gen, self.gen) > 2) accepted = 1;
		} else {
			/* Rifiuto ed eventualmente abbasso aspettative */
			printf("[VITA_A]{%d} Ho rifiutato %d\n", getpid(), pretendente.pid);
			accepted = 0;
			if (countMsgBA >= totB) adapted = 1;
			printf("[VITA_A]{%d}Ho abbassato il mio target.\n", getpid());
		}

		/* Informa B se è stato accettato o meno */
		msgp2.mtype = getpid();
		msgp2.accepted = accepted;
		if (msgsnd(ab_msgq_id, &msgp2, sizeof(int), 0) == -1) errExit("[ERRORE]msgsnd");
	}

	/* Rilascio semaforo */
	if (releaseSem(sem_id, 0) == -1) errExit("[ERRORE]releaseSem");

	/* Invio al gestore i dati dell'ultimo contatto */
	if (msgsnd(ag_msgq_id, &msgp, sizeof(Person), 0) == -1) errExit("[ERRORE]msgsnd");

	/* Staccati dalla memoria */
	if (shmdt(persons) == -1) errExit("[ERRORE]shmdt");

	/* Muori */
	return EXIT_SUCCESS;
}
