#include "type.h"

/* Gestione segnali */
volatile int stop_simulation = 0;

/* Handler dei segnali */
/* (per ragioni di sicurezza le stampe da handler non sono raccomandabili) */
static void handler(int sig) {
	if (sig == SIGTERM) {
		printf("[VITA_B]Ricevuto SIGTERM dal gestore.!\n");
		stop_simulation  = 1;
		return;
	}
}

/*-------------------------------------------------*/
/* --------- METODO PRINCIPALE DI VITA B --------- */
/*-------------------------------------------------*/
int main(int argc, char const *argv[]) {
	/* Persone (processi) */
	Person self;
	Node *persons;
	/* Flags */
	int accepted = 0, match = 0;
	/* Messaggi */
	struct infomsg msgp;
	struct lovemsg msgp2;
	/* Risorse */
	int sem_id, shm_id, ba_msgq_id, ab_msgq_id, startsem;
	char *myfifo;
	int fd;
	/* Iteratori */
	Node *iterator = NULL;


	printf("[VITA_B]{%d} Sono stato creato!\n", getpid());
	/* Associazione segnali con handler */
	if (signal(SIGUSR1, handler) == SIG_ERR) errExit("[ERRORE]signal B");

	/* Recupera info da argv e crea persona */
	self.is_b = atoi(argv[1]);
	self.name = (char *)argv[2];
	self.gen = (unsigned long) atoi(argv[3]);
	self.pid = getpid();


	/* --------- Associazione Risorse ---------*/

	/* Semaforo memoria condivisa */
	sem_id = semget(SEM_KEY, 1, 0666);
	if (sem_id == -1) errExit("[ERRORE]semget 1");

	/* Semaforo inizio */
	startsem = semget(START_SEM_KEY, 1, IPC_CREAT | 0666);
	if (startsem == -1) errExit("[ERRORE]semget 1");

	/* Memoria condivisa */
	shm_id = shmget(SHM_KEY, sizeof(Person), 0666);
	if (shm_id == -1) errExit("[ERRORE]shmid");
	persons = (Node *)shmat(shm_id, NULL, SHM_RDONLY);
	if (persons == (void *) -1) errExit("[ERRORE]shmat");

	/* Ottieni code di messaggi */
	ba_msgq_id = msgget(BA_MSGQ_KEY, 0666);
	if (ba_msgq_id == -1) errExit("[ERRORE]msgget BA");
	ab_msgq_id = msgget(AB_MSGQ_KEY, 0666);
	if (ab_msgq_id == -1) errExit("[ERRORE]msgget AB");

	/* Crea FIFO */
	myfifo = (char *)malloc(sizeof("./tmp/") + sizeof(itoa(self.pid)));
	sprintf(myfifo, "./tmp/%d", self.pid);
	if (mkfifo(myfifo, 0666) == -1) errExit("[ERRORE]mkfifo");

	/* --------- Associazione risorse ---------*/
	printf("[VITA_B]{%d} Ho recuperato le risorse.\n", getpid());


	if (reserveSem(startsem, 0) == -1) errExit("[ERRORE]reserveSem");
	while (!accepted && !stop_simulation) {
		printf("[VITA_B]{%d} Cerco partner.\n", getpid());
		/* Prova a leggere dalla memoria condivisa */
		if (reserveSem(sem_id, 0) == -1) errExit("[ERRORE]reserveSem");
		for (iterator = persons; iterator != NULL; iterator = iterator->next) {
			if (mcd(iterator->p.gen, self.gen) > 2) {
				match = 1; /* ho trovato un match */
				printf("[VITA_B]{%d} Ho trovato un match con %d.\n", getpid(), iterator->p.pid);
			}
		}
		if (releaseSem(sem_id, 0) == -1) errExit("[ERRORE]releaseSem");

		/* Contatta match (se trovato) e attendi risposta */
		if (match) {
			msgp.mtype = iterator->p.pid;
			msgp.p = self;
			printf("[VITA_B]{%d} Provo a contattare %d.\n", getpid(), iterator->p.pid);
			if (msgsnd(ba_msgq_id, &msgp, sizeof(Person), 0) == -1) errExit("[ERRORE]msgsnd");
			if (msgrcv(ab_msgq_id, &msgp2, sizeof(int), iterator->p.pid, 0666) == -1) errExit("[ERRORE]msgrcv");
			accepted = msgp2.accepted;
			printf("[VITA_B]{%d}%s %d.\n", getpid(), (accepted) ? "Sono stato accettato da" : "Capita anche ai migliori, sono stato rifiutato da", iterator->p.pid);
		}
	}

	/* Comunica al gestore l'accopiamento tramite FIFO */
	printf("[VITA_B]{%d} Avviso il Gestore del mio accoppiamento con %d.\n", getpid(), iterator->p.pid);
	fd = open(myfifo, O_WRONLY);
	if (fd == -1) errExit("[ERRORE]open");
	if (write(fd, &iterator->p, sizeof(Person)) == -1) errExit("[ERRORE]write");
	close(fd);

	/* Rimuovi fifo */
	printf("[VITA_B]{%d} Rimuovo le mie risorse, addio!\n", getpid());
	if (unlink(myfifo) == -1) errExit("[ERRORE]unlink");

	/* Muori */
	return EXIT_SUCCESS;
}



