/*
	TODO aggiungere stampe di cosa sta facendo il programma
	del tpo "[PROGRAMMA]messaggio" oppure "[PROGRAMMA]{id_processo}messaggio"
	Esempio nel metodo handler e vitaB.c
	*/

#include "type.h"

/* Gestione segnali */
volatile int end_simulation = 0, force_repopulation = 0;

/* Handler dei segnali */
/* (per ragioni di sicurezza le stampe da handler non sono raccomandabili) */
static void handler(int sig) {
	if (sig == SIGUSR1) { /* simulation timer */
		printf("[GESTORE] Tempo simulazione scaduto!\n");
		end_simulation = 1;
		return;
	}
	if (sig == SIGUSR2) { /* birth_death timer */
		printf("[GESTORE] Forzo ripopolamento!\n");
		force_repopulation = 1;
		return;
	}
}

/*-------------------------------------------------*/
/* -------- METODO PRINCIPALE DEL GESTORE -------- */
/*-------------------------------------------------*/
int main(int argc, char const *argv[]) {
	/* Iteratori */
	int i;
	iNode *iterator;
	/* Risorse */
	int sem_id, ag_msgq_id, ba_msgq_id, ab_msgq_id, shm_id, startsem;
	char *myfifo = NULL;
	int fd;
	/* Statistiche */
	Person person_max_name, person_max_gen;
	unsigned long maxgen = 0;
	int maxname = 0;
	int minPID = 2147483647;
	iNode *pids;
	/* Varie */
	Person person, tmp, child1, child2;
	struct infomsg msgp;
	Person *persons;
	char *alphabet[26] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
	/* Flags */
	int totalea=0, totaleb=0;

	/* Da input */
	int nump, birth_death, simulation;
	unsigned long genes;

	srand(time(NULL));

	printf("\n\n[GESTORE] Avviato, attendo input utente.\n");

	/* Associazione segnali con handler */
	if (signal(SIGUSR1, handler) == SIG_ERR) errExit("[ERRORE]signal 1");
	if (signal(SIGUSR2, handler) == SIG_ERR) errExit("[ERRORE]signal 2");


	/* -------- Ricevi input -------- */
	do {
		printf("Inserisci il numero massimo di processi da creare (int >= 2):\n");
		scanf("%d", &nump);
	} while (nump < 2);
	persons = (Person *)malloc(nump * sizeof(Person));
	printf("Inserisci il genoma (unsigned long):\n");
	scanf("%lu", &genes);
	printf("Inserisci il tempo di vita di un processo in secondi (int):\n");
	scanf("%d", &birth_death);
	printf("Inserisci il tempo della simulazione in secondi (int):\n");
	scanf("%d", &simulation);


	printf("[GESTORE] Input ricevuti.\n");
	printf("[GESTORE] Inizio creazione risorse...\n");

	/* -------- Creazione risorse -------- */

	/* Semaforo memoria condivisa */
	sem_id = semget(SEM_KEY, 1, IPC_CREAT | 0666);
	if (sem_id == -1) errExit("[ERRORE]semget 1");
	if (initSem(sem_id, 0, 1) == -1) errExit("[ERRORE]initSem");
	printf("[GESTORE] Semaforo memoria condivisa creato.\n");

	/* Semaforo inizio */
	startsem = semget(START_SEM_KEY, 1, IPC_CREAT | 0666);
	if (startsem == -1) errExit("[ERRORE]semget 1");
	if (initSem(startsem, 0, 0) == -1) errExit("[ERRORE]initSem");
	printf("[GESTORE] Semaforo start creato.\n");

	/* Coda messaggi A-B */
	ab_msgq_id = msgget(AB_MSGQ_KEY, IPC_CREAT | 0666);
	if (ab_msgq_id == -1) errExit("[ERRORE]msgget AB");
	printf("[GESTORE] Coda di messaggi da A a B creata.\n");

	/* Coda messaggi da A a Gestore */
	ag_msgq_id = msgget(AG_MSGQ_KEY, IPC_CREAT | 0666);
	if (ag_msgq_id == -1) errExit("[ERRORE]msgget AG");
	printf("[GESTORE] Coda di messaggi da A a GESTORE creata.\n");

	/* Coda messaggi da B-A */
	ba_msgq_id = msgget(BA_MSGQ_KEY, IPC_CREAT | 0666);
	if (ba_msgq_id == -1) errExit("[ERRORE]msgget BA");
	printf("[GESTORE] Coda di messaggi da B ad A creata.\n");

	/* Memoria condivisa (lista di persone A) */
	shm_id = shmget(SHM_KEY, sizeof(Node), IPC_CREAT | 0666);
	if(shm_id == -1) errExit("[ERRORE]shmget");
	printf("[GESTORE] Memoria condivisa creata.\n");

	/* -------- Creazione risorse -------- */

	printf("[GESTORE] Tutte le risorse sono state create.\n");

	printf("[GESTORE] Inizio la generazione di informazioni dei %d processi.\n", nump);
	/* Creazione persone A e B */
	for (i=0; i < nump; i++) {
		(persons+i)->is_b = rand() % 2;
		if (i == nump-1) { /* forza ultimo al tipo che manca */
			if (totalea == 0) (persons+i)->is_b = 0;
			if (totaleb == 0) (persons+i)->is_b = 1;
			if ((persons+i)->is_b) ++totaleb;
			else ++totalea;
			printf("[GESTORE] Ho dovuto forzare diversità.\n");
		}

		(persons+i)->name = alphabet[rand()%26];
		(persons+i)->gen = (unsigned long) rand() % ((2+genes)-2)+2;
		/* Aggiorna statistiche */
		update_highscores(*(persons+i), &maxgen, &maxname, &person_max_gen, &person_max_name, &minPID);
	}
	printf("[GESTORE] Informazioni generate e salvate, avvio i processi iniziali.\n");


	/* Avvio nump processi e simulazione */
	for (i=0; i < nump; i++) {
		spawn_process(*(persons+i), totaleb, &pids);
	}
	sleep(3);
	printf("[GESTORE] Processi avviati.\n");

	/* Avvio timer simulazione */
	start_timer(simulation, SIGUSR1);
	/* Avvio timer birth_death */
	start_timer(birth_death, SIGUSR2);
	printf("[GESTORE] Avviati i timer, simulazione avviata.\n");
	if (initSem(startsem, 0, nump) == -1) errExit("[ERRORE]initSem");

	while(!end_simulation) {
		/* Attendi match (non bloccante) */
		if (msgrcv(ag_msgq_id, &msgp, sizeof(Person), 0, IPC_NOWAIT) != -1 ) {
			person = msgp.p;
			printf("[GESTORE] Ho ricevuto un accoppiamento da un A con %d.\n", person.pid);
			/* Leggi dalla FIFO di person.pid */
			sprintf(myfifo, "./tmp/%d", person.pid);
			fd = open(myfifo, O_RDONLY);
			if (fd == -1) errExit("[ERRORE]open");
			if (read(fd, &tmp, sizeof(Person)) == -1) errExit("[ERRORE]read");
			close(fd);
			printf("[GESTORE] Ho ricevuto conferma accoppiamento tra %d e %d.\n", person.pid, tmp.pid);

			/* Accopiamento doppio (uno per ogni genitore) */
			printf("[GESTORE] Creo informazioni figli di %d e %d.\n", person.pid, tmp.pid);
			child1 = reproduce(person, tmp, genes, &totalea, &totaleb);
			child2 = reproduce(tmp, person, genes, &totalea, &totaleb);

			/* Aggiorna statistiche */
			update_highscores(child1, &maxgen, &maxname, &person_max_gen, &person_max_name, &minPID);
			update_highscores(child2, &maxgen, &maxname, &person_max_gen, &person_max_name, &minPID);

			/* Attendo morte dei due genitori */
			printf("[GESTORE] Attendo morte dei genitori (%d e %d).\n", person.pid, tmp.pid);
			waitpid(person.pid, NULL, 0);
			waitpid(tmp.pid, NULL, 0);
			delete_int_from_list(&pids, person.pid);
			delete_int_from_list(&pids, tmp.pid);

			/* Avvio dei processi creati */
			printf("[GESTORE] %d e %d sono morti, avvio i processi figli.\n", person.pid, tmp.pid);
			spawn_process(child1, totaleb, &pids);
			spawn_process(child2, totaleb, &pids);

		} else { /*msgrcv ha ritornato errore*/
			if (errno != ENOMSG) errExit("[ERRORE]msgrcv AG");
		}

		/* Forzo la repopolazione (se il timer è scaduto) */
		if (force_repopulation) {
			kill(minPID, SIGTERM);
			printf("[GESTORE] Ho ucciso %d perchè pid minore.\n", minPID);
			/* Crea nuova persona */
			printf("[GESTORE] Rimpiazzo il processo morto (%d).\n", minPID);
			person.is_b = rand() % 2;
			if (totalea == 0) persons[i].is_b = 0;
			if (totaleb == 0) persons[i].is_b = 1;
			if (persons[i].is_b) ++totaleb;
			else ++totalea;
			(persons+i)->name = alphabet[rand()%26];
			person.gen = rand() % ((2+genes)-2)+2;

			/* Aggiorna statistiche */
			minPID = find_min(pids);
			update_highscores(person, &maxgen, &maxname, &person_max_gen, &person_max_name, &minPID);
			spawn_process(person, totaleb, &pids);

			/* Reset timer */
			force_repopulation = 0;
			start_timer(birth_death, SIGUSR2);
		}
	}
	/* Uccidi gentilmente tutti */
	printf("[GESTORE] La simulazione è terminata, uccido tutti... gentilmente.\n");
	iterator = pids;
	while (iterator != NULL) {
		if (kill(iterator->num, SIGTERM) == -1) errExit("[ERRORE] kill");
		iterator = iterator->next;
	}
	/* Attendi che tutti terminino */
	for (i=nump; i > 0; i--) {
		printf("waiting\n");
		wait(NULL);
	}

	/* -------- Liberazione risorse -------- */
	printf("[GESTORE] Libero le risorse.");
	if (semctl(sem_id, 0, IPC_RMID) == -1) errExit("[ERRORE]semctl");
	if (msgctl(ab_msgq_id, IPC_RMID, NULL) == -1) errExit("[ERRORE]msgctl 1");
	if (msgctl(ag_msgq_id, IPC_RMID, NULL) == -1) errExit("[ERRORE]msgctl 2");
	if (msgctl(ba_msgq_id, IPC_RMID, NULL) == -1) errExit("[ERRORE]msgctl 3");
	if (shmctl(shm_id, IPC_RMID, NULL) == -1) errExit("[ERRORE]shmctl");
	free(persons);


	/* Stampa statistiche */
	printf("[GESTORE]Simulazione terminata.\n\nProcessi A:\t%d\nProcessi B:\t%d\nProcesso con il nome più lungo:\n", totalea, totaleb);
	print_person(person_max_name);
	printf("Processo con il genoma più alto:\n");
	print_person(person_max_gen);

	return EXIT_SUCCESS;
}

