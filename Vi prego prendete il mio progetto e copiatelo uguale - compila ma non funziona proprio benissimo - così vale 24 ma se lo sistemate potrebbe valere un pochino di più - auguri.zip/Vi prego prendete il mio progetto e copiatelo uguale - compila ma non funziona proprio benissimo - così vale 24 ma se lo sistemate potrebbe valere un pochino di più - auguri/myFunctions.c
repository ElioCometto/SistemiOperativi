#include "type.h"

/* Esce con errore, stampa a video s */
void errExit(char *s) {
	FILE *fp;
	if ((fp = fopen(LOGPATH, "a+"))) {
		fprintf(fp, "%s\n", s);
		fclose(fp);
	}

	perror(s);
	exit(EXIT_FAILURE);
}

/* Riserva il semaforo semNum, di semID */
int reserveSem(int semId, int semNum) {
	struct sembuf sops;

	sops.sem_num = semNum;
	sops.sem_op = -1;
	sops.sem_flg = 0;

	return semop(semId, &sops, 1);
}

/* Rilascia il semaforo semNum di semID */
int releaseSem(int semId, int semNum) {
	struct sembuf sops;

	sops.sem_num = semNum;
	sops.sem_op = 1;
	sops.sem_flg = 0;

	return semop(semId, &sops, 1);
}

/* Inizializza il semfaoro semnum di semid al valore val*/
int initSem(int semId, int semNum, int val) {
	union semun arg;

	arg.val = val;
	return semctl(semId, semNum, SETVAL, arg);
}

/* Creea un figlio tra parent1 e parent2, aggiorna i totali dei processi creati */
Person reproduce(Person parent1, Person parent2, unsigned long genes, int *tota, int *totb) {
	Person p;
	p.name = NULL;
	unsigned long x;
	p.is_b = rand() % 2;
	if (tota == 0) p.is_b = 0;
	if (totb == 0) p.is_b = 1;
	if (p.is_b) ++totb;
	else ++tota;
	sprintf(p.name, "%s%c", parent1.name, rand() % ('Z'-'A'+1)+'A');
	x = mcd(parent1.gen, parent2.gen);
	p.gen = rand() % ((genes+1)-x)+x;

	return p;
}

/* Trova il Massimo Comun Divisore tra a e b */
unsigned long mcd(unsigned long a, unsigned long b) {
	while (a != b) {
		if (a > b) a = a - b;
		else b = b - a;
	}
	return a;
}

/* Genera un processo per child */
void spawn_process(Person child, int totB, iNode **pids) {
	int pid;
	pid = fork();
	if (pid == -1) {
		errExit("[ERRORE]fork");
	} else if (pid == 0) {
		if (child.is_b) execl("vitaB", "vitaB", itoa(child.is_b), child.name, itoa((int)child.gen), NULL);
		else execl("vitaA"," vitaA", itoa(child.is_b), child.name, itoa((int)child.gen), itoa(totB), NULL);
		errExit("[ERRORE]spawn_process: execl");
	}
	add_int_to_list(pids, pid);
}

/* Aggiorna le statistiche e i processi associati a queste associati */
void update_highscores(Person p, unsigned long *maxgen, int *maxname, Person *pmaxg, Person *pmaxn, int *minPID) {
	if (strlen(p.name) >= *maxname) {
		*maxname = strlen(p.name);
		*pmaxn = p;
	}
	if (p.gen >= *maxgen){
		*maxgen = p.gen;
		*pmaxg = p;
	}
	if (p.pid <= *minPID) *minPID = p.pid;
}

/* Custom timer così da poter gestire due timers */
void start_timer(int seconds, int signal) {
	int ppid = getpid();
	int pid = fork();
	if (pid == -1) {
		errExit("[ERRORE]start_timer: fork");
	} else if (pid == 0) {
		sleep(seconds);
		kill(ppid, signal);
		exit(EXIT_SUCCESS);
	}
}

/* Stampa in modo leggibile le informazioni di una persona */
void print_person(Person p) {
	char gender = (p.is_b) ? 'B' : 'A' ;
	printf("------------------------\n");
	printf("Genere:\t%c\nNome:\t%s\nGenoma:\t%lu\nPid:\t%d\n", gender, p.name, p.gen, p.pid);
	printf("------------------------\n");
}

/* Scrive un intero come stringa */
char * itoa(int i) {
	char *a = (char *)malloc(findn(i));
	sprintf(a, "%d", i);
	return a;
}

/* Trova il numero di cifre in num*/
int findn(int num) {
	int n = 0;
	if (num == 0) return 1;
	while(num) {
		num /= 10;
		n++;
	}
	return n;
}

/* Aggiunge una persona alla lista puntata da h */
void add_to_list(Node **h, Person p) {
	Node *iterator, *new;

	iterator = *h;

	new = (Node *)malloc(sizeof(Node));
	new->p = p;
	new->next = NULL;

	if (*h == NULL) { /* lista vuota */
		*h = new;
	} else { /* aggiungo in fondo */
		while (iterator->next != NULL) iterator = iterator->next;
		iterator->next = new;
	}
}

/* Cancella un nodo con pid = pid dalla lista puntata da h*/
void delete_from_list(Node **h, int pid) {
	Node *tmp, *curr, *prec;
	if ((*h)->p.pid == pid) { /* rimuovo head */
		tmp = *h;
		*h = (*h)->next;
		free(tmp);
		return;
	}
	curr = (*h)->next;
	prec = *h;
	while (curr != NULL && prec != NULL) {
		if (curr->p.pid == pid) { /* rimuovo il nodo cercato */
			tmp = curr;
			prec->next = curr->next;
			free(tmp);
			return;
		}
		prec = curr;
		curr = curr->next;
	}
	return;
}

/* Aggiunge un intero alla lista puntata da h */
void add_int_to_list(iNode **h, int num) {
	iNode *iterator, *new;

	iterator = *h;

	new = (iNode *)malloc(sizeof(iNode));
	new->num = num;
	new->next = NULL;

	if (*h == NULL) { /* lista vuota */
		*h = new;
	} else { /* aggiungo in fondo */
		while (iterator->next != NULL) iterator = iterator->next;
		iterator->next = new;
	}
}

/* Rimuove num dalla lista puntata da h */
void delete_int_from_list(iNode **h, int num) {
	iNode *tmp, *curr, *prec;
	if ((*h)->num == num) { /* rimuovo head */
		tmp = *h;
		*h = (*h)->next;
		free(tmp);
		return;
	}
	curr = (*h)->next;
	prec = *h;
	while (curr != NULL && prec != NULL) {
		if (curr->num == num) { /* rimuovo il nodo cercato */
			tmp = curr;
			prec->next = curr->next;
			free(tmp);
			return;
		}
		prec = curr;
		curr = curr->next;
	}
	return;
}

/* Trova l'intero minimo nella lista puntata da h */
int find_min(iNode *h) {
	int min = 2147483647;
	iNode *iterator = h;
	while (iterator != NULL) {
		if (iterator->num <= min) min = iterator->num;
		iterator = iterator->next;
	}
	return min;
}
